#!/bin/bash
echo "Cargando Educascope..."
python main.py
